# FIX_PATCH_PLAN.md

Minimal patch list (aligned to ORPHANS_AND_GAPS)

Patch 1 - Bind contract review validation to the canonical schema file
- Files: plans/contract_review_validate.sh, docs/schemas/contract_review.schema.json
- Change:
  - In plans/contract_review_validate.sh, add a schema drift check that reads docs/schemas/contract_review.schema.json and compares required fields and enums to the validator expectations before running jq validation.
  - Fail fast if the schema file is missing or diverges (this makes docs/schemas/contract_review.schema.json a real consumer input, eliminating the orphan).
- Rationale: specs/WORKFLOW_CONTRACT.md §7 names docs/schemas/contract_review.schema.json as canonical; validator must reference it.

Patch 2 - Document existing Ralph gates and optional artifacts in the workflow contract
- Files: specs/WORKFLOW_CONTRACT.md
- Change:
  - Add a subsection under §5 (Ralph Harness Protocol) to document:
    - scope_gate behavior (scope.touch/scope.avoid fail-closed) as implemented in plans/ralph.sh.
    - story verify allowlist (plans/story_verify_allowlist.txt) and RPH_ALLOW_UNSAFE_STORY_VERIFY override.
    - rate limiting + circuit breaker behavior (RPH_RATE_LIMIT_*, RPH_MAX_SAME_FAILURE, RPH_MAX_NO_PROGRESS) and blocked reasons.
  - Add a note under §6 (Iteration Artifacts) listing optional diagnostics: .ralph/iter_*/story_verify.log, diff_for_cheat_check.patch, diff_for_cheat_check.filtered.patch, progress_appended.txt.
- Rationale: steps already enforced in plans/ralph.sh should be specified in specs/WORKFLOW_CONTRACT.md to avoid step-without-spec gaps.

How to test (required by workflow contract)
1) ./plans/workflow_acceptance.sh
2) ./plans/verify.sh full
