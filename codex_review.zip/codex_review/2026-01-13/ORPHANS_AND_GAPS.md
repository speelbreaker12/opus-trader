# ORPHANS_AND_GAPS.md

Priority order: P0 (highest) -> P3 (lowest)

P0 - ORPHANED schema file referenced by spec but unused by code
- Evidence:
  - specs/WORKFLOW_CONTRACT.md §7 requires contract_review.json to conform to docs/schemas/contract_review.schema.json.
  - plans/contract_review_validate.sh validates contract_review.json using embedded jq checks and never reads docs/schemas/contract_review.schema.json.
- Orphaned artifact: docs/schemas/contract_review.schema.json (no runtime consumer).
- Exact fix:
  - Update plans/contract_review_validate.sh to read docs/schemas/contract_review.schema.json and fail if it diverges from the validator expectations (see FIX_PATCH_PLAN.md Patch 1).

P1 - Step-without-spec: scope gate is enforced but not documented
- Evidence:
  - plans/ralph.sh scope_gate fails iteration if changed files are outside scope.touch or match scope.avoid.
  - specs/WORKFLOW_CONTRACT.md defines scope.touch/avoid fields but does not specify a scope enforcement step.
- Exact fix:
  - Add a new subsection under specs/WORKFLOW_CONTRACT.md §5 (Ralph Harness Protocol) documenting scope_gate behavior, including fail-closed semantics and the file patterns used in plans/ralph.sh (see FIX_PATCH_PLAN.md Patch 2).

P1 - Step-without-spec: story verify allowlist gate is enforced but not documented
- Evidence:
  - plans/ralph.sh run_story_verify requires plans/story_verify_allowlist.txt unless RPH_ALLOW_UNSAFE_STORY_VERIFY=1.
  - specs/WORKFLOW_CONTRACT.md does not mention allowlisting or plans/story_verify_allowlist.txt as a required input.
- Exact fix:
  - Add a subsection to specs/WORKFLOW_CONTRACT.md §5.6 (Story verify requirement gate) to specify allowlist enforcement and file path plans/story_verify_allowlist.txt (see FIX_PATCH_PLAN.md Patch 2).

P2 - Step-without-spec: rate limiting and circuit breaker gates are enforced but not documented
- Evidence:
  - plans/ralph.sh rate_limit_before_call (RPH_RATE_LIMIT_*), rate_limit_restart_if_slept, and circuit breaker gates (RPH_MAX_SAME_FAILURE / RPH_MAX_NO_PROGRESS) can stop iterations with blocked artifacts.
  - specs/WORKFLOW_CONTRACT.md does not mention these gates or their block reasons (BLOCKED_CIRCUIT_BREAKER, BLOCKED_NO_PROGRESS).
- Exact fix:
  - Add a subsection to specs/WORKFLOW_CONTRACT.md §5 describing rate limiting and circuit breaker behavior, default env vars, and blocked artifact reasons (see FIX_PATCH_PLAN.md Patch 2).

P3 - Extra iteration artifacts not listed in the spec
- Evidence:
  - plans/ralph.sh creates .ralph/iter_*/story_verify.log, diff_for_cheat_check.patch, diff_for_cheat_check.filtered.patch, progress_appended.txt.
  - specs/WORKFLOW_CONTRACT.md §6 lists required artifacts but not these optional artifacts.
- Exact fix:
  - Document these artifacts as optional diagnostics in specs/WORKFLOW_CONTRACT.md §6 (see FIX_PATCH_PLAN.md Patch 2).
